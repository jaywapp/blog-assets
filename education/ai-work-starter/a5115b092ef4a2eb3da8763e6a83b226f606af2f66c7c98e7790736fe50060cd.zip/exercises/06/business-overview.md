# 다온문구 월간 보고 업무 개요

- 버전: 1.0
- 작성일: 2026-10-28
- 자료 성격: 교육용 가상 회사, 실제 경영 성과 아님
- 적용 범위: 2026년 9월 월간 업무 보고, 7~9월 추이 참고
- 독자: 가상 운영팀장
- 목적: 확정 가능한 수치와 확인이 필요한 이슈를 구별해 보고

## 자료 역할

- monthly-performance.xlsx: 수치·날짜·합계 검증의 입력
- meeting-notes.docx: 이슈 설명 참고. 의견은 확정 원인과 구별
- previous-report.pdf: 구성·표현 참고. 당월 수치의 근거 아님
- report-template.docx: 출력 양식
- report-rules.md: 공통 보고 지침
- report-policy.md: 이 수업의 보조 지침. 공통 지침과 충돌하면 확인

## 위치

- 입력: 02-projects/monthly-report/inputs
- 중간 작업: 02-projects/monthly-report/working
- 최종본: 05-outputs/monthly-report
- 검증·상태: 06-logs/monthly-report

## 성공 기준

기간·단위·계산 근거가 명확하고, 원본의 누락·날짜 이상·합계 불일치를 발견해 기록한다. 승인 전 임의 보정하지 않는다. 확인받지 못한 내용은 확인 필요로 남긴다. 파일을 생성했다는 응답만으로 성공하지 않으며 실제 열기와 내용 검증이 필요하다.
