# Cowork 업무 위임문

Work의 완성본·작업 사본·정답표를 첨부하지 말고 같은 원본 다섯 파일로 시작한다.
보고 기간은 다온문구 2026년 9월, 비교 월은 8월이다.
입력: 02-projects/monthly-report/inputs
사본: 02-projects/monthly-report/working/cowork
산출물: 05-outputs/cowork / 로그: 06-logs/cowork-session.md

## 순차로 보낼 지시
1. 실제 읽을 수 있는 파일·적용 지침·계획·중단 지점을 설명하세요.
   아직 보고서를 만들지 마세요. 원본 수정·삭제·외부 전송은 금지합니다.
2. 누락 매출·잘못된 날짜·신고 합계 불일치를 위치·원래 값·영향·질문으로
   표에 적으세요. 확인 전 관련 총액과 증감률을 확정하지 말고 멈추세요.
3. 사람이 항목별 확인값·근거를 제공한 뒤 사본에만 반영하세요.
   미확정 사항은 유지하고 9월 보고서·분석표·검증 기록을 생성하세요.
   분석표에는 7~9월 요약·8월 대비 9월 증감·오류·계산 근거를 포함하세요.
   전월 0은 계산 불가, 단위·반올림은 보고 규칙을 따르세요.
4. 파일별 실제 위치·수행 검사·미수행 검사를 알려주세요.

## 결과 파일
- 월간 업무 보고서-cowork-v01.docx
- 실적 분석표-cowork-v01.xlsx
- 검증 결과-cowork-v01.md

## 실행 메모
- 화면 유형 / 계정 기능 / 모델 / 실행일:
- 로컬 폴더 연결 또는 첨부 / 실제 읽기 확인:
- 데스크톱 연결 여부 / 제한:
- Work와 동일하게 제공한 확인 응답:
- 산출물 위치 / 사람이 연 결과 / 재작업:

## 파일 위치와 승인 연습
입력 세 파일은 inputs, report-rules.md는 00-guides, report-template.docx는 04-templates에 있다. 첨부 방식에서는 다섯 파일을 이름별로 선택하고 Harness·Context를 추가한다.
AI가 오류를 질문한 뒤 교육생이 common/approval-card.md를 직접 읽고 승인 메시지만 전달한다. 실제 외부 담당자 확인은 필요 없는 가상 승인 연습이다. 카드 전체와 expected-results.xlsx는 AI 연결 범위 밖에 두며 정답표는 마지막 사람 검증에만 사용한다. 가상 입력의 AI 첨부 외 추가 제3자 서비스 전송은 허용하지 않는다.

## 이번 실행의 Harness 경로
- working-path: 02-projects/monthly-report/working/cowork
- output-path: 05-outputs/cowork
- verification-path: 06-logs/cowork
- session-log: 06-logs/cowork-session.md

기본 경로 대신 위 값을 permissions·verification·실행 지시에 동일하게 적용한다. 보고서·표는 output-path, 검증 결과는 verification-path에 저장한다.
