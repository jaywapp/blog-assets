# 05차시 실습: Windows Workspace

이 문서는 제품 설치 파일이 아닙니다. 탐색기와 메모장으로 아래 구조를 만드세요. `Documents`는 자신의 문서 폴더이며 OneDrive 등으로 실제 주소가 다를 수 있습니다.

```text
AI-Workspace/
  00-guides/
  01-context/
  02-projects/monthly-report/inputs/
  02-projects/monthly-report/working/
  03-skills/
  04-templates/
  05-outputs/monthly-report/
  06-logs/monthly-report/
```

공통 실적·회의록·이전 보고서는 inputs에 복사합니다. 양식은 04-templates, report-rules.md는 00-guides, company-profile.md와 업무 지표 정의인 business-glossary.md는 01-context에 복사합니다. common/glossary.md는 AI 학습 사전이므로 업무 용어집과 구분합니다. 작업 Excel은 working에 복사하고 이름에 working을 붙입니다. 원본 패키지는 별도로 보존합니다.

폴더명은 사람을 위한 분류입니다. AI의 자동 인식이나 접근 허가를 뜻하지 않습니다. 제품의 파일 첨부·폴더 선택·지침 등록을 확인해야 합니다. 텍스트로 원본 수정 금지를 적는 것은 실제 OS 쓰기 권한 변경과 다릅니다.

체크리스트를 working으로 복사하고 작성 결과를 06-logs/monthly-report에 보관하세요. 이 단계에서는 실제 사내 파일을 연결하지 않습니다.
