# 월간 보고 컨텍스트 목록

- 실행 ID: 2026-09-run-01
- 기준 경로: Documents/AI-Workspace
- 실제 Workspace 주소: 학습자가 탐색기에서 확인
- 자료 확인일: 미확인

| 상대 위치 | 역할 | 읽기 결과·버전 |
|---|---|---|
| 00-guides/report-rules.md | 공통 보고 규칙 | 미확인 |
| 00-guides/report-policy.md | 보조 보고 기준 | 미확인 |
| 00-guides/monthly-report-harness/ | 실행·권한·검증·복구 | 미확인 |
| 01-context/business-overview.md | 업무 배경·기간 | 미확인 |
| 01-context/business-glossary.md | 지표·용어 정의 | 미확인 |
| 02-projects/monthly-report/inputs/monthly-performance.xlsx | 원본 수치·날짜 | 미확인 |
| 02-projects/monthly-report/inputs/meeting-notes.docx | 설명·의견 참고 | 미확인 |
| 02-projects/monthly-report/inputs/previous-report.pdf | 구성 참고 | 미확인 |
| 04-templates/report-template.docx | 출력 양식 | 미확인 |

## 추가 근거

- 평가자 전용: 교육 패키지 common/approval-card.md와 common/expected-results.xlsx는 AI 연결 범위 밖에 보관한다.
- AI의 오류 질문 뒤 교육생이 approval-card.md를 직접 읽고 승인 응답만 전달한다. 카드 전체와 정답표를 첨부하지 않는다.
- 확인 응답 기록: 미승인 / 실제 응답 후 항목·확인값·근거·승인 범위·시각 기록
- 지침 충돌:
- 시행일·버전 불명확 항목:
- 읽기 실패:

카드나 파일이 없으면 빈 파일로 대신하지 않는다. 실제 파일명이 다르면 원본을 확인한 뒤 이 목록을 갱신한다. 수정 날짜만으로 최신 기준을 판정하지 않는다.
