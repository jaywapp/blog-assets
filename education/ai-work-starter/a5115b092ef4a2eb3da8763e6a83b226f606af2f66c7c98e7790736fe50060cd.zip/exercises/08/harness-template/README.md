# 월간 보고 Harness v1 배치 안내

이 묶음은 사람이 검토하고 AI에게 명시적으로 전달할 운영 문서다. 자동 실행 프로그램이나 자동 인식 디렉터리가 아니다. 코딩·CLI·Git 설치가 필요하지 않다.

## 복사 위치

- instructions.md, permissions.md, workflow.md, verification.md, recovery.md → Documents/AI-Workspace/00-guides/monthly-report-harness/
- context-manifest.md → Documents/AI-Workspace/02-projects/monthly-report/
- state-template.md → Documents/AI-Workspace/06-logs/monthly-report/state-2026-09-run-01.md
- approval-template.md → Documents/AI-Workspace/06-logs/monthly-report/approval-2026-09-run-01.md
- 상위 harness-test-cases.md → Documents/AI-Workspace/02-projects/monthly-report/working/

상대 경로는 AI-Workspace를 기준으로 읽는다. 실제 제품에서는 지원되는 방식으로 각 파일을 첨부·연결·지침에 등록하고 적용 시험을 한다. 폴더명이나 파일명만으로 자동 적용된다고 가정하지 않는다. 지침 문서는 실제 OS 접근 제어를 변경하지 않는다.

건식 시험은 실제 실행과 구별해 기록한다. 최종 결과 생성은 후속 제품 실습에서 진행한다. 가상 담당자 확인카드의 답을 미리 추정하지 않는다. AI가 오류를 질문한 뒤 교육생이 패키지 common/approval-card.md를 직접 읽고 승인 응답만 제공한다. 카드·정답표 전체는 AI에 첨부하지 않는다.

기본 출력·검증 경로는 permissions.md의 변수로 관리한다. 09~10차시에는 Work/Cowork 실행 지시의 output-path·verification-path·working-path·session-log 값으로 갱신한 후 같은 값을 적용한다.
