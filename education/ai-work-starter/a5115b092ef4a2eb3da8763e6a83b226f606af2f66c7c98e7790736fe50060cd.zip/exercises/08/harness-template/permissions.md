# 권한 설계 및 실제 설정 확인

이 표는 원하는 행동 범위이며 실제 Windows·앱·연결 서비스 권한 설정이 아니다. 실제 제품에서 가능한 범위를 확인한다. 더 넓은 범위만 제공하면 파일 첨부와 결과 다운로드 등 대안을 검토한다.

| 행동 | 설계 범위 | 실제 제품 설정·검증 |
|---|---|---|
| 읽기 | 지정한 guides, context, inputs, templates | 확인 전 |
| 중간 작업 쓰기 | 02-projects/monthly-report/working | 확인 전 |
| 최종본 쓰기 | output-path (기본 05-outputs/monthly-report) | 확인 전 |
| 상태·검증 쓰기 | verification-path / session-log (기본 06-logs/monthly-report) | 확인 전 |
| 원본 덮어쓰기·삭제 | 별도 승인 필요 | 미승인 |
| 외부 공유·메일·메신저 발송 | 별도 승인 필요 | 미승인 |
| 실제 회사 데이터·계정 연결 | 정책·권한 확인 필요 | 미승인 |

## 실행별 경로

- working-path: 02-projects/monthly-report/working
- output-path: 05-outputs/monthly-report
- verification-path: 06-logs/monthly-report
- session-log: 06-logs/monthly-report/session.md

09~10차시는 실행 지시의 Work/Cowork 값으로 갱신하고 실제 제품의 쓰기 범위를 확인한다. 가상 입력을 교육생이 AI에 첨부하는 것은 실습 전달이며, 추가 제3자 서비스 전송·외부 발송은 허용하지 않는다.

## 실행 전 확인

- 사용 제품과 계정 환경:
- 선택한 폴더·파일:
- 실제 허용한 읽기·쓰기:
- 네트워크·외부 전송 관련 권한:
- 불필요한 권한을 줄인 방법:
- 확인일·확인자:

텍스트 금지 규칙만으로 OS 쓰기가 차단되었다고 말하지 않는다. 승인 요청은 대상 행동·경로·이유를 구체적으로 제시한다.
