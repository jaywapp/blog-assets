# Work 업무 위임문

## 실행 조건
- 가상회사 다온문구, 보고 월 2026년 9월, 비교 월 8월.
- 공통 원본 다섯 파일과 업무 Context·Harness를 제공한다.
- expected-results.xlsx는 평가자 전용이며 첨부하거나 연결하지 않는다.
- 입력: 02-projects/monthly-report/inputs
- 사본: 02-projects/monthly-report/working/work
- 산출물: 05-outputs/work / 기록: 06-logs/work-session.md

## 1단계: 확인만
실제로 읽을 수 있는 파일 목록과 적용 규칙을 설명하세요. 누락 파일과
실행할 수 없는 도구를 알리고 계획·확인 전 중단 지점을 제시하세요.
원본 수정·삭제·외부 전송은 하지 마세요. 아직 보고서 생성은 시작하지 마세요.

## 2단계: 입력 검사
누락 매출, 잘못된 날짜, 신고 합계 불일치를 실제 위치와 함께 표로 작성하세요.
원래 값·업무 영향·확인 질문을 포함하고 추정하지 마세요.
사람의 확인 전 해당 항목과 관련된 총액·증감률을 확정하지 마세요.

## 3단계: 사람 확인 후 실행
사람이 별도 제공한 항목별 확인값과 근거만 사본에 반영하세요.
미확정 사항은 유지하고 수정 이력을 기록하세요.
9월 보고서 DOCX, 분석표 XLSX, 검증 결과 Markdown을 v01로 만드세요.
분석표는 7~9월 요약, 전월 증감액·증감률, 오류 목록, 계산 근거를 포함하세요.
전월 값 0은 계산 불가로 표시하세요. 단위·반올림은 보고 규칙을 따르세요.
실제 수행 검사와 미수행 검사를 구분하고 파일별 저장 위치를 알리세요.

## 산출물 이름
- 월간 업무 보고서-work-v01.docx
- 실적 분석표-work-v01.xlsx
- 검증 결과-work-v01.md

## 실행 기록
- 실행일 / 서비스 화면 / 모델 / 환경:
- 파일 전달 방법 / 접근 범위:
- 시작 / 종료 / 사람이 쓴 준비·검토·수정 시간:
- 적용 지침 / Skill 버전:
- 확인 응답 / 미확정 사항:
- 실제 산출물 / 수행하지 못한 작업:

## 파일 위치와 승인 연습
입력 세 파일은 inputs, report-rules.md는 00-guides, report-template.docx는 04-templates에 있다. 첨부 방식에서는 다섯 파일을 이름별로 선택하고 Harness·Context를 추가한다.
AI가 오류를 질문한 뒤 교육생이 common/approval-card.md를 직접 읽고 승인 메시지만 전달한다. 실제 외부 담당자 확인은 필요 없는 가상 승인 연습이다. 카드 전체와 expected-results.xlsx는 AI 연결 범위 밖에 두며 정답표는 마지막 사람 검증에만 사용한다. 가상 입력의 AI 첨부 외 추가 제3자 서비스 전송은 허용하지 않는다.

## 이번 실행의 Harness 경로
- working-path: 02-projects/monthly-report/working/work
- output-path: 05-outputs/work
- verification-path: 06-logs/work
- session-log: 06-logs/work-session.md

기본 경로 대신 위 값을 permissions·verification·실행 지시에 동일하게 적용한다. 보고서·표는 output-path, 검증 결과는 verification-path에 저장한다.
