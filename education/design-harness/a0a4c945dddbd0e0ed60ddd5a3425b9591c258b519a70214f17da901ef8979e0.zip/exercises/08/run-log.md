# 08 실행 기록

작성일: __________ · Photoshop 버전: __________ · Illustrator 버전: __________

## 0. 내 화면에서 확인한 메뉴와 옵션

> 도움말 검색창에서 찾은 현재 버전의 이름을 그대로 적습니다. 확인하지 못한 것은 "미확인"으로 둡니다.

| 항목 | 내 화면의 이름·위치 |
|---|---|
| Photoshop 변수 정의·데이터 세트 가져오기 메뉴 | |
| 텍스트 교체용·이미지 교체용 변수 종류의 이름 | |
| Illustrator Variables 패널의 데이터 불러오기 버튼 | |
| Image Processor 위치 | |
| Batch 메뉴 위치 | |

## 1. 표본 실행 (정상 데이터)

| 앱 | 데이터 | 실행 행 | 출력 폴더 | 생성 파일 수 | 문구·가격·이미지 대조 결과 |
|---|---|---|---|---|---|
| Photoshop | campaign-variants-png.csv | V01~V03 | work/batch/variants/ | | |
| Illustrator | menu-cards.csv | M01, M06, M08 | work/batch/menu-cards/ | | |

## 2. Image Processor

| 항목 | 설정/결과 |
|---|---|
| 입력 폴더 | work/batch/variants/ |
| 출력 폴더 | work/batch/export/ |
| 저장 형식 | JPEG |
| 색 공간 변환 옵션 (이름과 선택 여부) | |
| 크기 조정 옵션 (이름) | 사용하지 않음 |
| 생성된 파일 수 / 오류 | |

## 3. Illustrator Action과 Batch

| 항목 | 설정/결과 |
|---|---|
| Action 이름 | outline-text-copy |
| 기록한 단계 | |
| Batch 입력 폴더 | work/batch/menu-cards-copy/ (복사본) |
| 처리된 파일 수 | |
| 원본 폴더의 파일은 그대로인가 | |

## 4. 증거와 판정

- 화면 캡처 파일명: __________
- 실행 중 멈추거나 오류가 난 곳과 대응: __________
- 전체 실행으로 넓혀도 되는가 (예 / 아니오 / 조건부): __________ (이유: __________)
- 이 기록으로 판단할 수 없는 것: __________
