# 08 데이터 검사 기록

작성일: __________ · 대상 파일: campaign-variants.csv, menu-cards.csv

> `campaign-exceptions.csv`와 `menu-card-exceptions.csv`는 시험용입니다. 실제 캠페인에 쓰지 않습니다.

## 1. 구조 확인

| 파일 | 열 이름 | 행 수(제목 제외) | 빈 칸 있음 | 인코딩 |
|---|---|---|---|---|
| campaign-variants.csv | | | | |
| menu-cards.csv | | | | |

## 2. 문구 대조 (campaign-variants.csv ↔ copy-deck.md)

| variant_id | headline | copy-deck에서 찾은 위치 | 일치 | price_text | 가격 표와 일치 |
|---|---|---|---|---|---|
| V01 | | | | | |
| V02 | | | | | |
| V03 | | | | | |

- V01의 헤드라인은 「상품별 헤드라인」과 「승인 문구」 표의 헤드라인이 다릅니다. 내가 쓰기로 한 쪽과 이유: __________

## 3. 이미지 경로

| variant_id | 원본 SVG | PNG로 저장했는가 | PNG 크기(px) | 경로가 CSV와 일치 |
|---|---|---|---|---|
| V01 | images/cake-strawberry.svg | | | |
| V02 | images/cake-choco.svg | | | |
| V03 | images/cookie-gift-box.svg | | | |

## 4. 메뉴 카드 데이터 (menu-cards.csv)

`common/menu.csv`를 카드용 문구로 가공한 파일입니다. 가공 규칙과 원본 대조를 확인합니다.

| 규칙 | 확인 |
|---|---|
| price_krw를 쉼표와 "원"을 붙인 문구로 바꿈 | |
| allergens 앞에 "알레르기: "를 붙임 | |
| allergens가 비어 있는 행은 비워 둠 ("없음"으로 채우지 않음) | |
| 12행의 가격이 menu.csv와 일치 | |

- 빈 알레르기 칸이 있는 메뉴 ID: __________ → 담당자에게 확인할 질문: __________

## 5. AI에게 점검을 맡겼다면

- 입력한 내용(가상 자료만): __________
- AI가 지적한 항목: __________
- 사람이 원본과 대조해 맞다고 확인한 것 / 틀리다고 확인한 것: __________
- 이 기록으로 판단할 수 없는 것: __________
