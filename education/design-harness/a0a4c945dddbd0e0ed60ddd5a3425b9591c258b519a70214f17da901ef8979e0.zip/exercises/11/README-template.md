# [프로젝트 이름] 하네스 README

> 이 파일은 `motungi-bakery-harness/README.md`로 복사해 사용합니다. 새 의뢰를 시작할 때 가장 먼저 읽는 문서입니다.

## 1. 이 프로젝트가 하는 일

- 의뢰자/브랜드: __________
- 주력 산출물: __________ (예: SNS 배너, 인쇄물 1종)
- 최종 승인자: __________ · 수정 횟수 약속: __________

## 2. 새 의뢰를 시작하는 순서

1. `brief.md`를 새로 만들고 미확정 항목을 표시한다.
2. `workflow.md`의 G0(입력 확인)을 통과했는지 확인한다.
3. `tasks/task-NNN.md`를 복사해 이번 작업을 적는다.
4. 작업본에서 제작한다. 승인본은 건드리지 않는다.
5. `review-checklist.md`로 검수하고 `review/review-NNN.md`에 증거를 남긴다.
6. `history/run-log.csv`와 `history/decisions.md`를 갱신한다.

## 3. 폴더 지도

| 위치 | 용도 |
|---|---|
| `brief.md`, `brand-guide.md`, `asset-manifest.csv` | 입력 |
| `workflow.md`, `review-checklist.md`, `tasks/` | 절차 |
| `assets/approved/`, `assets/references/` | 승인 자산 / 참고 자료 |
| `working/photoshop/`, `working/illustrator/` | 작업본 |
| `previews/`, `review/`, `delivery/` | 확인·검수·납품 |
| `history/` | 결정·로그·체크포인트 |

## 4. 하지 않는 일

- 승인 문구·가격·로고를 확인 없이 바꾸지 않는다.
- 입력이 부족한데 추측으로 제작하지 않는다.
- 인증 키·고객 개인정보를 문서에 적지 않는다.

## 5. 현재 버전

하네스 v1 · 마지막 갱신: __________ · 갱신 이유: __________
