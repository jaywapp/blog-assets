# 07 앱 간 인계 규칙

작성일: __________ · 담당자: __________

## 1. 자산별 원본과 사용처

| 자산 | 원본 앱·파일 | 쓰는 앱·파일 | 방식(연결/포함/복사) | 원본 수정 시 반영 | 원본 담당 |
|---|---|---|---|---|---|
| 로고 심볼 | Illustrator·logo-symbol.svg | | | | |
| 로고 기본형 | Illustrator·logo-primary.svg | | | | |
| 아이콘(딸기·쿠키·별) | Illustrator·work/brand/brand-assets.ai | | | | |
| 패턴 | Illustrator·work/brand/brand-assets.ai | | | | |
| 색상 6개 | colors.json·라이브러리 | | | | |
| 제품 일러스트 | images/ | | | | |
| 마스터 PSD | Photoshop·work/campaign/feed-1080x1350-master_v1.psd | | | | |

## 2. 인계 규칙

| 상황 | 규칙 |
|---|---|
| 원본을 수정할 때 | |
| 수정 후 확인할 파일 | |
| 파일을 다른 폴더로 옮길 때 | |
| 링크가 끊겼을 때 | |
| 서체 파일은 누가 배포하는가 | |
| 라이브러리를 쓸 수 없을 때의 대체 경로 | |

## 3. 폴더 구조 메모

```text
motungi-bakery/
  brief.md  brand-guide.md  asset-manifest.csv
  source/          받은 재료 (common 복사본, 수정 금지)
  work/brand/      로고·아이콘·패턴 AI (03·06차시)
  work/direction/  방향 썸네일 (04차시)
  work/campaign/   마스터·배너 PSD, 메뉴판 AI (05·07차시)
  previews/  review/  history/
```

추가한 하위 폴더와 이유: __________
